PROMPT **** Desinstalaci�n de la tabla, procedimiento y secuencia de seguimiento TRACE
SET NUM 20
desc pr_trace
desc tb_trace

select *
  from user_sequences
 where seQuence_name = 'SQ_TRACE'
/

drop procedure pr_trace;
drop table tb_trace;
drop sequence sq_trace;

desc pr_trace
desc tb_trace

select *
  from user_sequences
 where seQuence_name = 'SQ_TRACE'
/
