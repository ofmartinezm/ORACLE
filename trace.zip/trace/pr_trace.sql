create or replace
procedure pr_trace (p_consultor varchar2
                   ,p_programa  varchar2
                   ,p_mensaje   varchar2
                   ) is
  pragma autonomous_transaction;
begin
  insert into tb_trace
   (trc_codnum
   ,trc_usuario
   ,trc_terminal
   ,trc_sesion
   ,trc_programa
   ,trc_consultor
   ,trc_fecha
   ,trc_mensaje
   ) values
   (sq_trace.nextval
   ,user
   ,userenv('terminal')
   ,userenv('sessionid')
   ,p_programa
   ,p_consultor
   ,sysdate
   ,p_mensaje
   );
   commit;
end;
/
grant execute on pr_trace to AGOOCU;
-- Create synonyms
create or replace public synonym pr_trace for pr_trace;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
