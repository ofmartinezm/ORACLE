drop table tb_trace
;
create table tb_trace
 (trc_codnum     number
 ,trc_usuario    varchar2(100)
 ,trc_terminal   varchar2(100)
 ,trc_sesion     varchar2(100)
 ,trc_programa   varchar2(100)
 ,trc_consultor  varchar2(100)
 ,trc_fecha      date
 ,trc_mensaje    varchar2(4000)
 )
;
grant select, insert, update, delete on tb_trace to AGOOCU;
-- Create synonyms
create or replace public synonym tb_trace for tb_trace;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
