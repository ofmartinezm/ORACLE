spool trace.log
start sq_trace.sql
start tb_trace.sql
start pr_trace.sql
spool off
