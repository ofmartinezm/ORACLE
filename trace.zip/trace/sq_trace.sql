prompt ===========================================================================================================================================================
PROMPT -- COIAC-4629 Estado Matr�cula - UPI
PROMPT -- sq_trace.sql: Creaci�n Secuencia sq_trace "Secuencia Trace - Tabla TB_TRACE"
prompt ===========================================================================================================================================================
set lines 1000

PROMPT -- Desc secuencia antes:
select *
  from all_sequences
 where sequence_owner = 'UXXIAC'
   and sequence_name  = 'sq_trace'
;

-- Create sequence 
create sequence sq_trace
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20
;

PROMPT -- Show errors:
show err

PROMPT -- Create Public Synonym
CREATE OR REPLACE PUBLIC synonym sq_trace FOR sq_trace;

PROMPT -- Grant/Revoke object privileges:
grant select on sq_trace to AGOOCU;
grant select on sq_trace to AGO_T_SOLOCONSULTA;
grant select on sq_trace to CONSULTA;
grant select on sq_trace to PUBLIC;

PROMPT -- Desc secuencia despu�s:
select *
  from all_sequences
 where sequence_owner = 'UXXIAC'
   and sequence_name  = 'sq_trace'
;

prompt ===========================================================================================================================================================
